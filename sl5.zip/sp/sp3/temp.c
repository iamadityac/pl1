#include<stdio.h>
#include<ctype.h>

int main()
{
    int a=1;
    printf("\n\tisdigit : %d",isdigit(a));
    return 0;
}
